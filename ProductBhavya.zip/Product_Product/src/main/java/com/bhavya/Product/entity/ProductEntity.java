package com.bhavya.Product.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class ProductEntity {
	
	@Id
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer productId;
	@Column(nullable = false)
	private String type;
	public Integer getProductId() {
		
		return null;
	}
	
	
	

}
