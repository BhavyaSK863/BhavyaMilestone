package com.bhavya.Product.service;

import java.util.List;
import java.util.Optional;

import com.bhavya.Product.VO.ProductWithDescriptionVO;
import com.bhavya.Product.entity.ProductEntity;


public interface ProductService {

	public Optional<ProductEntity> getById(Integer productId);
	public List<ProductEntity> getByType(String type);
	public void addProduct(ProductEntity product);
	public ProductWithDescriptionVO getProductWithDescription(Integer productId);
}
