package com.bhavya.Product.VO;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDescriptionVO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer descId;
	@Column(nullable=false)
	private String brand;
	@Column(nullable=false)
	private String model;
	@Column(nullable=false)
	private Integer prize;

}