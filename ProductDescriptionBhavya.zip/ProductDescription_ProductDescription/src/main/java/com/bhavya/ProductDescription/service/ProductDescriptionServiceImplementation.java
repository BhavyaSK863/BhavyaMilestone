package com.bhavya.ProductDescription.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bhavya.ProductDescription.entity.*;
import com.bhavya.ProductDescription.repository.*;

@Service
public class ProductDescriptionServiceImplementation implements ProductDescriptionService {

	@Autowired
	private ProductDescriptionRepository repository;
	
	@Override
	public Optional<ProductDescriptionEntity> getById(Integer descId) {
		return repository.findById(descId);
	}

	@Override
	public void addDescription(ProductDescriptionEntity description) {
		repository.save(description);
		
	}

}