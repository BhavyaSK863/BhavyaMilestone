package com.bhavya.ProductDescription.vo;

public class ProductWithDescription {

}
