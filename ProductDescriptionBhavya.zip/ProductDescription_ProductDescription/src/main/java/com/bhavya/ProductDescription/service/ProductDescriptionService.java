package com.bhavya.ProductDescription.service;


import java.util.Optional;

import com.bhavya.ProductDescription.entity.*;

public interface ProductDescriptionService {

	public Optional<ProductDescriptionEntity> getById(Integer descId);
	public void addDescription(ProductDescriptionEntity description);
}
