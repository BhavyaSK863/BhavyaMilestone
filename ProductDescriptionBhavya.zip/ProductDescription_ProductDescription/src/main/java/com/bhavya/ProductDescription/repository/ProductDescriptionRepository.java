package com.bhavya.ProductDescription.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bhavya.ProductDescription.entity.*;

@Repository
public interface ProductDescriptionRepository extends JpaRepository<ProductDescriptionEntity, Integer>{

}